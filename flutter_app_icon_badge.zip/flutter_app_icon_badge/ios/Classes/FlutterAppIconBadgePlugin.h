#import <Flutter/Flutter.h>

@interface FlutterAppIconBadgePlugin : NSObject<FlutterPlugin>
@end
