## [2.0.0]

* Null-safety

## [1.0.1]

* All methods return Future

## [1.0.0]

* Initial Release. iOS, Android, MacOS
