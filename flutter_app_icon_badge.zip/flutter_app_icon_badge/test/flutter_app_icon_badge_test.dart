// import 'package:flutter/services.dart';
// import 'package:flutter_test/flutter_test.dart';
// import 'package:flutter_app_icon_badge/flutter_app_icon_badge.dart';

void main() {
  // const MethodChannel channel = MethodChannel('flutter_app_icon_badge');
  //
  // TestWidgetsFlutterBinding.ensureInitialized();
  //
  // setUp(() {
  //   channel.setMockMethodCallHandler((MethodCall methodCall) async {
  //     return '42';
  //   });
  // });
  //
  // tearDown(() {
  //   channel.setMockMethodCallHandler(null);
  // });
  //
  // test('isAppBadgeSupported', () async {
  //   expect(await FlutterAppIconBadge.isAppBadgeSupported, '42');
  // });
}
